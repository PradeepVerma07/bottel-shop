# Bottle Shop editable Shopify theme

The reference homepage is implemented as eight reusable Shopify Liquid sections on the downloaded Dawn theme. It includes 245 section and block setting fields, shared design settings, local fonts, clean photography, arrow buttons, and independent hero sliders.

The latest source refresh pulled theme **189990240349** from **eazf8k-q9.myshopify.com** on November 19, 2026, then added the completed Bottle Shop sections. The homepage order is hero, collections, story, gathering, store and newsletter, with the custom header and footer in their groups. The fresh pull is backed up in `../shopify-theme-pulled-original-189990240349-20261119-162523.zip`. The changes are local; the live theme has not been modified.

## Open and edit

The complete local theme is in `shopify-theme/`. The installable package is `bottle-shop-editable-theme.zip` in the parent project folder.

To review it in Shopify, upload that ZIP as a new theme from **Online Store → Themes → Add theme → Upload ZIP file**, then open **Customize** for the uploaded theme. This work has not been uploaded or published to the store. The original downloaded theme is preserved separately in `shopify-theme-original.zip`.

Select **Home page** in the theme editor. The header and footer appear in their respective groups; the six page sections appear between them. Use **Add section** and search for **Bottle Shop** to reuse a page section on a JSON template. Page sections can be duplicated, reordered, hidden, or removed. The custom header is limited to one instance to preserve Dawn's cart integration.

## Section controls

| Editor section | File | Editable content and layout |
| --- | --- | --- |
| Bottle Shop header | `sections/bottle-header.liquid` | Logo, brand name, desktop/mobile logo sizes, Shopify menu or navigation link blocks, search/account/cart visibility and labels, homepage overlay, colors and spacing. |
| Bottle Shop hero | `sections/bottle-hero.liquid` | Slide blocks with desktop/mobile images, image position, separate desktop/mobile shading, headings, description, two buttons, product link, right-side signature, caption, colors, heights, typography, alignment, circle arrows, counters and optional autoplay. |
| Bottle Shop collections | `sections/bottle-collections.liquid` | Add/reorder card blocks; choose a collection, replace its image/title/link, edit Browse text, select included photography, adjust columns and card heights for desktop/mobile. |
| Bottle Shop story | `sections/bottle-story.liquid` | Eyebrow, heading, description, button, paper background, separate photograph and caption, photo side/height/rotation, optional seal and its text, colors, font sizes and padding. |
| Bottle Shop gathering | `sections/bottle-gathering.liquid` | Background image, image position, copy, button/link, shading, alignment, copy width, desktop/mobile height, font sizes, colors and padding. |
| Bottle Shop store | `sections/bottle-store.liquid` | Store heading, accent heading, description, photograph, wood sidebar background, left/right layout, sidebar width, directions button/link, optional badge, detail blocks, icon choices and visibility. |
| Bottle Shop newsletter | `sections/bottle-newsletter.liquid` | Background, heading, description, email label/placeholder, subscribe label, success message, privacy text, colors, font sizes and padding. Uses Shopify's customer newsletter form. |
| Bottle Shop footer | `sections/bottle-footer.liquid` | Logo, menu/contact blocks, labels, links, location/phone icons, brand message, Instagram/Facebook URLs, copyright/year, responsibility text, age note, tagline, background, colors and spacing. |

Click a slide/card/detail/menu block in the editor to change that item. Select a hero slide block to display it immediately while editing. Duplicated sliders keep their own controls and state. Autoplay is off initially and pauses for keyboard focus, reduced-motion preference, hidden tabs and theme editing.

## Replace images and connect store content

Every photo/background/logo slot has an image picker. Upload or select an image to override the included image. Where supplied, turn off **Use included…** or choose **None** to remove the fallback asset. Hero slides also have separate mobile images and mobile positioning/shading controls.

Headings, descriptions, captions, buttons and decorative marks are real Liquid/HTML content. Lettering physically inside a photograph or logo belongs to that image; replace the image to change that lettering. The hero's right-side signature and the story photo caption are separate editable text.

Choose real **collections** for collection cards and real **menus** for navigation/footer columns. Starter shop buttons currently lead to `/collections/all` until you select a specific destination. A hero slide's product picker supplies its primary button URL when its custom button link is empty; slide copy stays independently editable.

Store hours, address, phone number and directions URL use the reference's sample details. Edit them in the store section and footer contact block. Social icons appear after their URLs are supplied, using the footer URLs or Dawn's social settings.

## Fonts, colors and visibility

Open **Theme settings → Bottle Shop design** for shared colors, body/button font sizes, button arrows, page width and desktop/mobile gutters. The reference look uses bundled Anton headings and Montserrat body text. Enable **Use theme typography** to use Dawn's native **Typography** settings instead. Font licenses are included in `assets/bs-font-licenses.css`.

Section color overrides start empty and inherit the shared palette, except the story section's cream/ink scheme. Set an override for a single section or clear it to inherit again. Body sizes inherit globally while **Inherit global body size** is enabled; disable that switch to use the section's own size. Heading sizes and relevant layout controls have desktop/mobile settings.

Clear a button label to remove that button. Clear optional copy to remove it. In the store section, disable **Show detail icons**, choose **None** for an individual icon, or remove a detail block. Toggle the badge/seal off independently. The global arrow switch controls button arrows; hero circle controls have their own section switch and accessible labels.

Optional navigation anchors are provided for collections, story, store and newsletter. The starter links point to these anchors. If a section is duplicated with the same anchor, only the first instance receives the matching ID. Set a different anchor and update links when you want to target the duplicate. Newsletter input/form IDs always include the section instance ID.

## Code and integrations

`assets/bottle-shop.css` and `assets/bottle-shop.js` are shared once through `snippets/bottle-assets.liquid`, rendered in `layout/theme.liquid`. Shared snippets handle buttons, SVG icons, responsive media and scoped style variables. Section CSS is scoped to the custom classes; the storefront has no added runtime package dependencies.

`templates/index.json` sets the initial homepage order. `sections/header-group.json` and `sections/footer-group.json` select the custom global sections. The native product, collection, cart, search, account and other templates remain available. The custom header retains Dawn's cart icon update target and native cart notification rendering for the existing notification cart setting.

## Verification

- Rendered all eight production Liquid sections locally with explicit Shopify asset/image/customer-form stubs; verified edited text and icon/badge toggles reach the generated markup.
- Validated setting IDs, range/default values, presets, template/block references and included asset/snippet paths.
- Checked the rendered page at 1440px, 390px and 320px, with no horizontal overflow, broken images or duplicate IDs.
- Exercised independent duplicated sliders, editor block-selection events, removal/reconnection, mobile navigation/Escape, duplicated newsletter forms and unique named anchors.
- Checked edited body/button sizes and section padding on desktop and narrow mobile layouts; verified the autoplay pause control remains available on mobile.
- Shopify Theme Check reports **zero custom issues and zero added issues**. The original downloaded Dawn theme and this theme both report **35,008 existing errors and 9 warnings**, primarily existing translation checks. The overall Theme Check command therefore exits with failure; it is not a clean baseline.
- The downloaded theme did not contain its referenced package manifest, test runner or contributing/release files, so the referenced pnpm scripts could not be run. Validation used Shopify CLI Theme Check, production Liquid rendering and browser checks instead.

The local preview verifies layout and component behavior. Shopify-hosted editor behavior, native cart requests and newsletter submissions have not been tested against the store. No live upload or publication was performed.

Project validation details are in `../.bottle-shop-qa/validation-summary.json`; visual previews are in `../previews/shopify-desktop.jpg` and `../previews/shopify-mobile.jpg`. Those development files are excluded from the installable theme ZIP. The cleaned hero image and generation record remain in `../assets/edits/hero-photo-no-copy.png` and `../assets/edits/hero-photo-no-copy-prompts.json`.

Shopify references: [section schema](https://shopify.dev/docs/storefronts/themes/architecture/sections/section-schema), [input settings](https://shopify.dev/docs/storefronts/themes/architecture/settings/input-settings), [section groups](https://shopify.dev/docs/storefronts/themes/architecture/section-groups).
